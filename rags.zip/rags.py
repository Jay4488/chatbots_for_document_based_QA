# import chromadb
# from langchain_community.vectorstores import Chroma
# from langchain_huggingface import HuggingFaceEmbeddings
# from dotenv import load_dotenv
# from langchain_google_genai import ChatGoogleGenerativeAI
# from langchain_community.document_loaders import DirectoryLoader, PDFMinerLoader

# load_dotenv()

# llm= ChatGoogleGenerativeAI(model='gemini-2.0-flash', temperature=0.7)

# loader=PDFMinerLoader(r"C:\Users\Admin\Downloads\Jay Patel Resume.pdf") ### Enter your document path
# load_pdf=loader.load()

# # load_pdf

# from langchain_text_splitters import RecursiveCharacterTextSplitter
# text_splitter=RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=50)
# text= text_splitter.split_documents(load_pdf)

# # print(text)

# from langchain import embeddings
# persist_directory='db'
# embedding=HuggingFaceEmbeddings(model_name='all-MiniLM-L6-v2')

# vector_db= Chroma.from_documents(documents=text,
#                                  embedding=embedding,
#                                  persist_directory=persist_directory
#                                  )

# vector_db.persist()
# vector_db=None

# vector_db=Chroma(persist_directory=persist_directory, embedding_function=embedding)

# retrive=vector_db.as_retriever(search_kwargs={"k":2})
# docs=retrive.get_relevant_documents('What is python')

# from langchain.chains import RetrievalQA
# chain=RetrievalQA.from_chain_type(llm=llm, chain_type='stuff', retriever=retrive, return_source_documents=True)

# query="what is python"
# response=chain(query)
# print(response['result'])




# from langchain_community.vectorstores import FAISS
# from langchain_community.vectorstores import Chroma
# from langchain_huggingface import HuggingFaceEmbeddings
# from dotenv import load_dotenv
# from langchain_google_genai import ChatGoogleGenerativeAI
# from langchain_community.document_loaders import PDFMinerLoader
# from langchain_text_splitters import RecursiveCharacterTextSplitter
# from langchain.chains import RetrievalQA

# # Load environment variables (make sure GOOGLE_APPLICATION_CREDENTIALS is set)
# load_dotenv()

# # Initialize LLM
# llm = ChatGoogleGenerativeAI(model='gemini-2.0-flash', temperature=0.7)

# # Load PDF
# pdf_path = r"C:\Users\Admin\Downloads\Jay Patel Resume.pdf"
# loader = PDFMinerLoader(pdf_path)
# documents = loader.load()
# # print(documents)

# # # Split text
# text_splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=50)
# chunks = text_splitter.split_documents(documents)

# # Create or load vector database
# embedding = HuggingFaceEmbeddings(model_name='all-MiniLM-L6-v2')

# vector_db = FAISS.from_documents(
#         documents=chunks,
#         embedding=embedding,
    
#     )
# # print("✅ Vector DB created in temporary dir.")

# retriever = vector_db.as_retriever(search_kwargs={"k": 2})

# # # Setup RAG chain
# chain = RetrievalQA.from_chain_type(
#     llm=llm,
#     chain_type='stuff',
#     retriever=retriever,
#     return_source_documents=True
# )

# # # Run query
# query = "who is jay patel"
# response = chain.invoke({"query": query})
# print(response['result'])  



















import streamlit as st
import tempfile
import os
from dotenv import load_dotenv
from langchain_community.document_loaders import PDFMinerLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import FAISS
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain.chains import RetrievalQA

# Load environment variables
load_dotenv()

st.set_page_config(page_title="📄 PDF Q&A with Gemini", layout="centered")
st.title("📄 Chat with your PDF using Gemini AI")

# Upload PDF
uploaded_file = st.file_uploader("Upload a PDF file", type="pdf")

if uploaded_file:
    with st.spinner("Reading and processing PDF..."):
        # Save uploaded PDF to a temporary file
        with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp_file:
            tmp_file.write(uploaded_file.read())
            pdf_path = tmp_file.name

        # Load PDF using PDFMiner
        loader = PDFMinerLoader(pdf_path)
        documents = loader.load()

        # Split into chunks
        text_splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=50)
        chunks = text_splitter.split_documents(documents)

        # Embeddings
        embedding = HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")

        # Create FAISS DB
        vector_db = FAISS.from_documents(documents=chunks, embedding=embedding)

        # Retriever
        retriever = vector_db.as_retriever(search_kwargs={"k": 2})

        # Gemini LLM
        llm = ChatGoogleGenerativeAI(model="gemini-2.0-flash", temperature=0.7)

        # RAG chain
        chain = RetrievalQA.from_chain_type(
            llm=llm,
            chain_type="stuff",
            retriever=retriever,
            return_source_documents=True
        )

        st.success("✅ PDF processed. You can now ask questions!")

        # User query
        query = st.text_input("💬 Ask a question about the PDF")

        if query:
            with st.spinner("🔍 Generating answer..."):
                response = chain.invoke({"query": query})
                st.subheader("📌 Answer:")
                st.write(response["result"])

                with st.expander("📚 Source Chunks"):
                    for i, doc in enumerate(response["source_documents"]):
                        st.markdown(f"**Chunk {i+1}:**")
                        st.write(doc.page_content)
